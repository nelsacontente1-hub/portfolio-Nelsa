# Portfólio — Nelsa Contente

Portfólio pessoal criado com HTML, CSS e JavaScript puro. O projeto é responsivo e pode ser publicado gratuitamente no GitHub Pages.

## Estrutura

- `index.html` — conteúdo e estrutura do site
- `css/style.css` — cores, layout e adaptação para telemóveis
- `js/script.js` — menu móvel, ano automático e animações
- `assets/` — fotografia profissional

## Como abrir

Abra o ficheiro `index.html` no navegador.

## Publicar no GitHub Pages

1. Crie um repositório no GitHub.
2. Envie todos os ficheiros e pastas deste projeto.
3. Entre em **Settings → Pages**.
4. Em **Source**, selecione **Deploy from a branch**.
5. Escolha a branch `main`, pasta `/root`, e clique em **Save**.

O endereço será semelhante a `https://seu-utilizador.github.io/nome-do-repositorio/`.
